import React from 'react'
import FaqQuesAns from '../../Component/FAQ/FaqQuesAns'

const faqQuesAns = () => {
  return (
    <div>
        <FaqQuesAns/>
    </div>
  )
}

export default faqQuesAns