import React from 'react'
import ActiveProfiles from '../../Component/ProfileStatus/ActiveProfiles'

const activeProfiles = () => {
  return (
    <div>
      <ActiveProfiles/>
    </div>
  )
}

export default activeProfiles