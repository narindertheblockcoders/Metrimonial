import React from 'react'
import InactiveProfiles from '../../Component/ProfileStatus/InactiveProfiles'

const inactiveProfiles = () => {
  return (
    <div>
        <InactiveProfiles/>
    </div>
  )
}

export default inactiveProfiles