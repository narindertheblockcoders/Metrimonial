import React from 'react'
import AdminApprove from '../../Component/ProfileStatus/AdminApprove'

const adminApprove = () => {
  return (
    <div>
        <AdminApprove/>
    </div>
  )
}

export default adminApprove