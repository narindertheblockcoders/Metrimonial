import React from 'react'
import DisaproveProfile from '../../Component/ProfileStatus/DisaproveProfile'

const disaproveProfile = () => {
  return (
    <div>
      <DisaproveProfile/>
    </div>
  )
}

export default disaproveProfile