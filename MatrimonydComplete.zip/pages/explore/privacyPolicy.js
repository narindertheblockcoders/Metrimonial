import React from 'react'
import PrivacyPolicy from "../../Component/Explore/PrivacyPolicy"

const privacyPolicy = () => {
  return (
    <div>
        <PrivacyPolicy/>
    </div>
  )
}

export default privacyPolicy