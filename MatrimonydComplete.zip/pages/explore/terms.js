import React from 'react'
import Terms from "../../Component/Explore/Terms"

const terms = () => {
  return (
    <div>
        <Terms/>
    </div>
  )
}

export default terms