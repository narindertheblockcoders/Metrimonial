import React from 'react'
import AboutUs from "../../Component/Explore/AboutUs"

const aboutUs = () => {
  return (
    <div>
        <AboutUs/>
    </div>
  )
}

export default aboutUs