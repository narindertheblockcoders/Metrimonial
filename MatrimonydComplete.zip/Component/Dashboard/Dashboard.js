import Link from "next/link";
import React, { useEffect, useState, useRouter } from "react";
import axios from "axios";
import { CopyToClipboard } from "react-copy-to-clipboard";
import { ToastContainer, toast } from "react-toastify";
import SideBar from "../SideBar";
import ReactPaginate from "react-paginate";


const NewDashboard = () => {
  const [collectiveData, setCollectiveData] = useState();
  const [adminDetail, setAdminDetail] = useState();
  const [userData, setUserData] = useState();
  const [added, setAdded] = useState(0)
  const [isLoading, setIsLoading] = useState(false)
  const [searchData, setSearchData] = useState();
  const [currentPage, setCurrentPage] = useState(1);
  const [postsPerPage, setPostsPerPage] = useState(10);
  const [oldData, setOldData] = useState([]);


  async function getCollectiveData() {
    try {
      const token = localStorage.getItem("token");
      console.log(token, "to get the token from localStorage");
      let res = await axios.post("/api/dashboard/dashboard", { token: token });
      const response = res.data;
      console.log(
        response,
        "to get the response from api on dashboard for collective data"
      );
      setCollectiveData(response.data);
    } catch (err) {
      console.log(err);
    }
  }

  async function getAdminDetails() {
    try {
      const token = localStorage.getItem("token");
      console.log(token, "to get the token from localStorage");
      let res = await axios.post("/api/dashboard/adminDetails", { token: token });
      const response = res.data;
      console.log(
        response,
        "to get the response from api on dashboard for admin details"
      );
      setAdminDetail(response.data);
    } catch (err) {
      console.log(err);
    }
  }

  async function getUsers() {
    try {
      const token = localStorage.getItem("token");
      let res = await axios.post("/api/users/getUsers", { token: token });
      const response = res.data;
      console.log(response, "to get the response from api to get users");
      setOldData(response.data);
      setUserData(response.data);
    } catch (err) {
      console.log(err);
    }
  }


  useEffect(() => {
    getAdminDetails();
    getCollectiveData();
    getUsers();
  }, [added]);


  async function deleteUser(data){
    try{
    const res = await axios.post("/api/users/deleteUsers",data)
    const response= res.data
    console.log(response,"delete user response")
    setAdded(added+1)
    toast.success("Deleted Successfully")
    setIsLoading(true)

    
  }catch(err){
    setIsLoading(false)
    console.log(err)
  }
}

 async function deleteUserSubmitHandler(e){
  console.log(e,"item value")
  const data ={
    id:e,
  }
  deleteUser(data)
  setAdded(added+1)
 }


 async function serachFn(e) {
  console.log(e.target.value);
  const search = e.target.value;
  console.log(oldData, "old data here");
  const filteredData = oldData?.filter((item) => {
    const name = item?.name;
    return name?.toLowerCase().includes(search.toLowerCase());
  });
  console.log(filteredData, "to get the value of the filtered Data");
  const selected = 0;
  Pagination({ selected });
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  const searchPosts = filteredData?.slice(indexOfFirstPost, indexOfLastPost);
  console.log(searchPosts, "search post");

  setSearchData(searchPosts);

  if (search == "") {
    setUserData(userData);
  } else {
    setSearchData(searchPosts);
  }
  // setUsers(searchData)
}
 
  // Pagination
  const indexOfLastPost = currentPage * postsPerPage;
  const indexOfFirstPost = indexOfLastPost - postsPerPage;
  var currentPosts = userData?.slice(indexOfFirstPost, indexOfLastPost);

  const Pagination = ({ selected }) => {
    setCurrentPage(selected + 1);
    setSearchData(null);
    setUserData(userData);
  };



  return (
    <div className="new-dashboard">
      <SideBar />
      <section className="profile-sec profile-sects pt-0">
            {/* <div  className="left-dashboard  first-set  mb-4" id="leftt-section">
                {" "}
                <h5>Welcome -  {" "} {adminDetail?.firstName} </h5>
              </div> */}
        <div className="container">
          <div className="row">
            {/* <Navbar /> */}
            <form className="funds-sec">
              <h3 className="dummy-txts"> </h3>
              <ToastContainer />
              <div className="col-head mt-1 " id="col-head">
                <h6 className="dummy-txts mt-2 mb-4"  style={{ fontSize: "14px" }}>
                  {" "}
                </h6>
                {collectiveData?.map((item, id) => {
                  return (
                    <div key={id} className="col-md-12 left-headSec">
                      <div
                        className="link-head  "
                        id="first-sec"
                        style={{ justifyContent: "space-between" }}
                      >
                        <Link href={"/master/happyCoupleLatest"}>
                          <div
                            className="link-dashboard  first-set"
                            id="lr-section"
                          >
                            {" "}
                            <i
                              className="fa-sharp fa-solid fa-users "
                              id="dashboard-icons"
                            ></i>
                            <p className="dashboard-txts">{item.totalUser}</p>
                            <h6 className="dashboard-txt"> TOTAL USERS</h6>
                          </div>
                        </Link>

                        <Link href={"/users/totalUsers"}>
                        <div
                          className="link-dashboard  first-set"
                          id="firstet-item"
                          data-bs-toggle="modal"
                          href="#exampleModalToggle"
                        >
                          <i className="fa-solid fa-arrow-up-from-ground-water" id="dashboard-icons"></i>
                          <p className="dashboard-txts"> {}</p>
                          <h6 className="dashboard-txt "> LIST OF TESTIMONIALS</h6>
                        </div>
                        </Link>

                        <Link href={"/directIncome"}>
                          <div
                            className="link-dashboard first-set"
                            id="invest-item"
                          >
                            <i
                              className="fa-solid fa-hand-holding-dollar"
                              id="dashboard-icons"
                            ></i>
                            <p className="dashboard-txts">{}</p>
                            <h6 className="dashboard-txt"> TOTAL INCOME</h6>
                          </div>
                        </Link>

                        <Link href="/directIncome">
                          <div
                            className="link-dashboard first-set"
                            id="faquery-item"
                          >
                            <i
                              className="fa-solid fa-hand-holding-dollar"
                              id="dashboard-icons"
                            ></i>
                            <p className="dashboard-txts"> {}</p>
                            <h6 className="dashboard-txt">TOTAL PAYOUT </h6>
                          </div>
                        </Link>

                        {/* <Link href="/totalWithdraws">
                                      <div className="link-dashboard" id="teams-item">
                                        <i
                                          className="fa fa-filter-circle-dollar"
                                          id="dashboard-icons"
                                        ></i>
                                        <p className="dashboard-txts"></p>
                                        <h6 className="dashboard-txt">TOTAL WITHDRAWAL </h6>
                                      </div>
                                    </Link> */}

                        {/* <Link href={"/directIncome"}>
                                      <div
                                        className="link-dashboard  first-set"
                                        id="teams-item"
                                      >
                                        {" "}
                                        <i
                                          className="fa-solid fa-users"
                                          id="dashboard-icons"
                                        ></i>
                                        <p className="dashboard-txts"></p>
                                        <h6 className="dashboard-txt "> DIRECT INCOME</h6>
                                      </div>
                                    </Link> */}

                        {/* <Link href={"/allMatchingIncome"}>
                                          <div
                                            className="link-dashboard  first-set"
                                            id="teams-item"
                                          >
                                            {" "}
                                            <i
                                              className="fa-solid fa-users"
                                              id="dashboard-icons"
                                            ></i>
                                            <p className="dashboard-txts"></p>
                                            <h6 className="dashboard-txt "> MATCHING INCOME</h6>
                                          </div>
                                        </Link> */}

                        {/* <Link href={"/totalRocMatchingIncome"}>
                                            <div
                                              className="link-dashboard  first-set"
                                              id="teams-item"
                                            >
                                              {" "}
                                              <i
                                                className="fa-solid fa-users"
                                                id="dashboard-icons"
                                              ></i>
                                              <p className="dashboard-txts"></p>
                                              <h6 className="dashboard-txt "> ROC MATCHING INCOME</h6>
                                            </div>
                                          </Link> */}

                        {/* <Link href="/allTickets">
                                            <div className="link-dashboard" id="third-itemes">
                                              <i
                                                className="fa-solid fa-users-between-lines"
                                                id="dashboard-icons"
                                              ></i>
                                              <p className="dashboard-txts"></p>
                                              <h6 className="dashboard-txt"> SUPPORTED TICKET</h6>
                                            </div>
                                          </Link> */}
                      </div>
                    </div>
                  )
                })}
              </div>

              <div className="left-dashboard  " id="lr-id">
          
              <div className="search-bar-sec" id="pt-resp-totalusers">
                  <div className="input-group mb-1" id="search-bar-set">
                    <input
                      type="text"
                      style={{ paddingLeft: "0px" }}
                      className="input-group-text "
                      placeholder="Search"
                      onChange={(e) => serachFn(e)}
                      id="search-bg-set"
                    />
                    <span className="form-control ">
                      <i className="bi bi-search" id="search-iColor"></i>
                    </span>
                  </div>
                </div>
              <table className="table funds-table mt-3" id="funds-color">
              <thead>
                    <tr className="">
                      <th id="fuds" scope="col">
                        Sr. No.
                      </th>
                      <th id="fuds" scope="col">
                        Name
                      </th>
                      <th id="fuds" scope="col">
                        Gender
                      </th>
                      <th id="fuds" scope="col">
                        Age
                      </th>
                      <th id="fuds" scope="col">
                        Country
                      </th>
                      <th id="fuds" scope="col">
                        
                      </th>
                      <th id="fuds" scope="col"></th>

                      <th id="fuds" scope="col" ></th>
                      
                    </tr>
                  </thead>

                <tbody>
                {searchData == null ?
                currentPosts?.map((item,id)=>{
                 return(<>
                        <Link href="/users/totalUsers">
                      <tr >
                        <td className="total-account">
                          
                          {id+1}
                        </td>
                        <td className="total-account">
                          {item.name}
                           </td>
                        <td className="total-account">
                          {item.gender}</td>
                        <td className="total-account">
                        {item.age}</td>
                        <td className="total-account ">
                        {item.country}</td>
                 
                              
                        <td className="total-account " id="right-textset">
                                  {item?.adminApproved1 == 1 && item?.adminApproved2 == 1 ?  <button type="button" className="btn view-btn" id="approve-btn">
                                    Approved
                                  </button>: null }
                                
                                  {(item?.adminApproved1 == 1 &&  item?.adminApproved2 == 0) || (item?.adminApproved1 == 0 &&  item?.adminApproved2 == 1)|| ( item?.adminApproved1 == 0 && item?.adminApproved2 == 0) ?  <button type="button" className="btn view-btn" id="approvePending-btn">
                                    Pending
                                  </button> : null }
                                 

                                  {(item?.adminApproved1 == 2 || item?.adminApproved2 == 2)  || (item?.adminApproved1 == 2 &&  item?.adminApproved2 == 0) || (item?.adminApproved1 == 0 &&  item?.adminApproved2 == 2) || (item?.adminApproved1 == 1 &&  item?.adminApproved2 == 2) || (item?.adminApproved1 == 2 &&  item?.adminApproved2 == 1)? <button type="button" className="btn view-btn" id="disapprove-btn">
                                    Disapproved
                                  </button> : null }

                                 

                                 

                                  {/* <button type="button" className="btn view-btn" id="approvePending-btn">
                                    View
                                  </button>
                                  <button type="button" className="btn view-btn" id="disapprove-btn">
                                    View
                                  </button> */}

                              </td>
                            

                              <td className="total-account td-width" id="right-textset">
                                <Link href={"/editDetails/" + item.id}>

                                <i class="bi bi-pencil-square td-icons"  id="edit-btn"></i>
                                </Link>
                              </td>



                              <td
                                className="total-account  td-width"
                                onClick={() => deleteUserSubmitHandler(item?.id)}>
                                <i  style={{ cursor: "pointer" }} className="bi bi-trash3 td-icons" id="pin-dark-icon" ></i>{" "}
                              </td>
  
                            </tr>
                          </Link>
                          </>
                      ) ;
                    }):searchData?.map((item, id)=>{
                         return(<>
                      <Link href="/users/totalUsers">
                      <tr >
                        <td className="total-account">
                          
                          {id+1}
                        </td>
                        <td className="total-account">
                          {item.name}
                           </td>
                        <td className="total-account">
                          {item.gender}</td>
                        <td className="total-account">
                        {item.age}</td>
                        <td className="total-account ">
                        {item.country}</td>
                 
                              
                        <td className="total-account " id="right-textset">
                                  {item?.adminApproved1 == 1 && item?.adminApproved2 == 1 ?  <button type="button" className="btn view-btn" id="approve-btn">
                                    Approved
                                  </button>: null }
                                
                                  {(item?.adminApproved1 == 1 &&  item?.adminApproved2 == 0) || (item?.adminApproved1 == 0 &&  item?.adminApproved2 == 1)|| ( item?.adminApproved1 == 0 && item?.adminApproved2 == 0) ?  <button type="button" className="btn view-btn" id="approvePending-btn">
                                    Pending
                                  </button> : null }
                                 

                                  {(item?.adminApproved1 == 2 || item?.adminApproved2 == 2)  || (item?.adminApproved1 == 2 &&  item?.adminApproved2 == 0) || (item?.adminApproved1 == 0 &&  item?.adminApproved2 == 2) || (item?.adminApproved1 == 1 &&  item?.adminApproved2 == 2) || (item?.adminApproved1 == 2 &&  item?.adminApproved2 == 1)? <button type="button" className="btn view-btn" id="disapprove-btn">
                                    Disapproved
                                  </button> : null }

                                 

                                 

                                  {/* <button type="button" className="btn view-btn" id="approvePending-btn">
                                    View
                                  </button>
                                  <button type="button" className="btn view-btn" id="disapprove-btn">
                                    View
                                  </button> */}

                              </td>
                            

                              <td className="total-account td-width" id="right-textset">
                                <Link href={"/editDetails/" + item.id}>

                                <i class="bi bi-pencil-square td-icons"  id="edit-btn"></i>
                                </Link>
                              </td>



                              <td
                                className="total-account  td-width"
                                onClick={() => deleteUserSubmitHandler(item?.id)}>
                                <i  style={{ cursor: "pointer" }} className="bi bi-trash3 td-icons" id="pin-dark-icon" ></i>{" "}
                              </td>
  
                            </tr>
                          </Link>

                          </>
                          );

                    })
                  }
                  
                  
              
                </tbody>
              </table>
              </div>
            </form>
            <div className="paginate-sec">
                <ReactPaginate
                  previousLabel="← Previous"
                  nextLabel="Next →"
                  onPageChange={Pagination}
                  pageCount={Math.ceil(
                    userData?.length  / postsPerPage
                  )}
                  containerClassName="pagination"
                  previousLinkClassName="pagination__link"
                  nextLinkClassName="pagination__link"
                  disabledClassName="pagination__link--disabled"
                  activeClassName="pagination__link--active"
                  className="page-link"
                />
              </div>
          </div>
        </div>
      </section>
    </div>
  );
};
export default NewDashboard;
