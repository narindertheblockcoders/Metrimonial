import React from 'react'
import TotalUsers from '../../Component/Users/TotalUsers'

const totalusers = () => {
  return (
    <div>
        <TotalUsers/>
    </div>
  )
}

export default totalusers;