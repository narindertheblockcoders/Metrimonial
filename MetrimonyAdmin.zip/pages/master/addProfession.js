import React from 'react'
import AddProfession from '../../Component/Master/AddProfession'

const addProfession = () => {
  return (
    <div>
        <AddProfession/>
    </div>
  )
}

export default addProfession