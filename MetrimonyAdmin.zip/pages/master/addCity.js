import React from 'react'
import AddCity from '../../Component/Master/AddCity'

const addCity = () => {
  return (
    <div>
        <AddCity/>
    </div>
  )
}

export default addCity