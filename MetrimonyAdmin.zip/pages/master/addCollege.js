import React from 'react'
import AddCollege from '../../Component/Master/AddCollege'

const addCollege = () => {
  return (
    <div>
        <AddCollege/>
    </div>
  )
}

export default addCollege