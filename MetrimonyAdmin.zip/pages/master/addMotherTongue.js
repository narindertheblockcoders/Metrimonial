import React from 'react'
import AddMotherTongue from '../../Component/Master/AddMotherTongue'

const addCountry = () => {
  return (
    <div>
        <AddMotherTongue/>
    </div>
  )
}

export default addCountry