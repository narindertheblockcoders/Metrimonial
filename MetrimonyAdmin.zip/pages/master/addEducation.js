import React from 'react'
import AddEducation from '../../Component/Master/AddEducation'

const addEducation = () => {
  return (
    <div>
        <AddEducation/>
    </div>
  )
}

export default addEducation