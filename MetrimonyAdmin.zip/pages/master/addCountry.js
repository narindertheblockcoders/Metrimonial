import React from 'react'
import AddCountry from '../../Component/Master/AddCountry'

const addCountry = () => {
  return (
    <div>
        <AddCountry/>
    </div>
  )
}

export default addCountry