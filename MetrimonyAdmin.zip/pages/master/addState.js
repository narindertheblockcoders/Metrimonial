import React from 'react'
import State from '../../Component/Master/AddState'

const state = () => {
  return (
    <div>
        <State/>
    </div>
  )
}

export default state