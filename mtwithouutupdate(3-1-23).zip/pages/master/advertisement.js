import React from 'react'
import Advertisement from '../../Component/Master/Advertisement'

const advertisement = () => {
  return (
    <div>
        <Advertisement/>
    </div>
  )
}

export default advertisement