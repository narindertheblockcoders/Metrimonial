import React from 'react'
import HideCouplesList from '../../Component/Master/HideCouples'

const hideCouples = () => {
  return (
    <div>
        <HideCouplesList/>
    </div>
  )
}

export default hideCouples