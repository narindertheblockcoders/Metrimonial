import React from 'react'
import Query from '../../Component/Master/Query'

const query = () => {
  return (
    <div><Query/></div>
  )
}

export default query