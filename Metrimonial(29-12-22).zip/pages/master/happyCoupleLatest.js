import React from 'react'
import HappyCoupleLatest from '../../Component/Master/HappyCoupleLatest'

const happyCoupleLatest = () => {
  return (
    <div>
        <HappyCoupleLatest/>
    </div>
  )
}

export default happyCoupleLatest